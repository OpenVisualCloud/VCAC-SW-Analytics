#!/bin/bash

#############################################################################################
#
# prerequest:
# before run this script, please use command `sudo apt install lockfile-progs` to install tool
#
# notes:
# exit code and means.
#		Code		Means
#		0			Script execute successfully.
#		1			Start vpu_metric failed, reason: it has been started.
#		2			start vpu_metric failed, reason: start failed.
#		3			fetch vpu_metric pid failed, reason: not running.
#		4			stop vpu_metric failed, reason: kill command failed.
#############################################################################################

pwd_path=$(dirname $0)
PRO_NAME=vpu_metric
PID_FILE=$pwd_path/vpu_metric.pid
lock_cmd=''
unlock_cmd=''

setup()
{
	command -v lockfile || apt install lockfile-progs &> /dev/null
	if [ $? != 0 ]; then
		echo "apt install lockfile-progs failed..."
		exit $?
	fi
}

fetch_vpu_metric_pid_by_ps()
{
	ps_cmd=$(ps -Ae | grep vpu_metric | grep -v grep | awk '{print $1 ":" $4}')

	for item in $ps_cmd
	do
		name=${item##*:}
		if [ "$name" == "vpu_metric" ]; then
			pid=${item%%:*}
			echo $pid
			return 
		fi
	done
	echo 0
}

start()
{
	setup
	input_param="$@"

	__APPLY_ENV__

	pid=`fetch_vpu_metric_pid_by_ps`
	if [ "$pid" != "0" ]; then
		echo "Start vpu_metric failed. It is running, pid:" $pid
		return 1
	fi

    	# start vpu_metric
    	run_cmd=`nohup $pwd_path/bin/$PRO_NAME $input_param &> /dev/null &`
	# waiting program to start
	sleep 1

	pid=`fetch_vpu_metric_pid_by_ps`

	if [ "$pid" != "0" ]; then
		echo succeed to start $name pid: $pid
		echo $pid > $PID_FILE
		return 0
	fi

    	echo $run_cmd &> 2
    	return 2
}

start_debug()
{
	input_param="$@"
	__APPLY_ENV__
	$pwd_path/bin/$PRO_NAME $input_param
}

stop()
{
	pid=`fetch_vpu_metric_pid_by_ps`
	if [ "$pid" == "0" ];then
		echo $PRO_NAME has not started &> 2
		return 3
	fi
	if [ -f $PID_FILE ]; then
		fpid=`cat $PID_FILE`
		if [ "$pid" != "$fpid" ];then 
			echo "Warning: The running vpu_metric's pid is not compatiable to pid file. This may be cause by vpu_metric exceptly exit. please review log file to check."
		fi
	else
		echo "Warning: The running vpu_metric doesn't have pid file. This may be cause by deleting pid file exceptly or start vpu_metric by other motheds."
	fi
	echo "Try to stop vpu_metric..."
	kill -9 $pid
	if [ $? != 0 ];then
		echo Stop vpu_metric failed, reason: $2
		return 4
	fi
	> $PID_FILE
	return 0
}

status()
{
	pid=`fetch_vpu_metric_pid_by_ps`
	if [ $pid != 0 ];then
		echo $PRO_NAME has not started &> 2
		return 3
	fi

    	if [ -f $PID_FILE ]; then
        	pid=`cat $PID_FILE`
		if [ $pid != $fpid ];then 
			echo "Warning: The running vpu_metric's pid is not compatiable to pid file. This may be cause by vpu_metric exceptly exit. please review log file to check."
		fi
	else
		echo "Warning: The running vpu_metric doesn't have pid file. This may be cause by deleting pid file exceptly or start vpu_metric by other motheds."
    	fi
    	return 0
}

show_version()
{
	$pwd_path/bin/$PRO_NAME --vsn
}

lock()
{
	if ! command -v lockfile-create > /dev/null 2>&1; then
		if ! command -v lockfile > /dev/null 2>&1; then
			echo 'No lockfile or lockfile-create command, please install lockfile-progs before run this script!'
			exit $#
		fi
		lock_cmd="lockfile run.lock"
		unlock_cmd="rm -f run.lock"
	fi

	if [ -z $lock_cmd ]; then
		lock_cmd="lockfile-create run"
	fi
	if [ -z $unlock_cmd ]; then
		unlock_cmd="lockfile-remove run"
	fi

    	echo locking this script
    	$lock_cmd
}

unlock()
{
    	echo unlocking this script
    	$unlock_cmd
}

case C"$1" in
Cvsn)
    show_version
    exit
    ;;
esac

lock
trap unlock EXIT
trap unlock INT

case C"$1" in
Cstart)
    start __START_PARAM__
    ;;
Cdebug)
    start_debug __START_PARAM__
    ;;
Cstop)
    stop
    ;;
Crestart)
    stop && start __START_PARAM__
    ;;
Cstatus)
    status
    ;;
Cinit)
    setup
    ;;
C*)
    echo "Usage: $0 {start|debug|stop|restart|status}"
    ;;
esac

