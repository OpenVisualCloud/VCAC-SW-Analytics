# !/bin/bash
dir=$(cd $(dirname $0); pwd)

INSTALL_DIR=$dir/temp

dpkg -i $dir/intel-vcaa-benchmark*.deb
if [ $# != 0 ]; then
        echo "install vcaa_agent deb package failed..."
        exit
fi

if [ -z `command -v cmake` ]; then
        echo "[Error ] can't find cmake..."
        exit
fi

mkdir $dir/thirdparty -p
cd $dir/thirdparty

if [ ! -d glog ]; then
        git clone https://github.com/google/glog.git
fi
cd glog
git checkout v0.4.0
mkdir build -p && cd build
cmake -DBUILD_SHARED_LIBS:BOOL=ON .. && make

cd $dir/thirdparty
if [ ! -d grpc ]; then
        git clone https://github.com/grpc/grpc.git
fi
cd grpc
git checkout v1.20.x
git submodule update --init
cd third_party/protobuf
git checkout v3.6.1
cd ../..
cd third_party/gflags
mkdir build -p && cd build
cmake -DBUILD_SHARED_LIBS:BOOL=ON .. && make
cd ../../..

cd third_party/cares/cares
mkdir build -p && cd build
cmake -DCMAKE_INSTALL_PREFIX:PATH=${INSTALL_DIR}/c-ares .. && make && make install
cd ../../../..

cd third_party/protobuf
mkdir build -p && cd build
cmake -Dprotobuf_BUILD_TESTS:BOOL=OFF -Dprotobuf_WITH_ZLIB:BOOL=OFF -DBUILD_SHARED_LIBS:BOOL=ON -DCMAKE_INSTALL_PREFIX:PATH=${INSTALL_DIR}/protobuf ../cmake && make && make install
cd ../../..

cd third_party/zlib
mkdir build -p && cd build
cmake -DCMAKE_INSTALL_PREFIX:PATH=${INSTALL_DIR}/zlib  .. && make && make install
cd ../../..

export export LD_LIBRARY_PATH=${INSTALL_DIR}/protobuf/lib:$LD_LIBRARY_PATH
mkdir build -p && cd build
cmake -DBUILD_SHARED_LIBS:BOOL=ON -DgRPC_BUILD_TESTS:BOOL=OFF -DgRPC_PROTOBUF_PROVIDER:STRING=package -DgRPC_PROTOBUF_PACKAGE_TYPE:STRING=CONFIG -DProtobuf_DIR:PATH=${INSTALL_DIR}/protobuf/lib/cmake/protobuf -DgRPC_ZLIB_PROVIDER:STRING=package -DZLIB_ROOT:STRING=${INSTALL_DIR}/zlib -DgRPC_CARES_PROVIDER:STRING=package -Dc-ares_DIR:PATH=${INSTALL_DIR}/c-ares/lib/cmake/c-ares -DgRPC_SSL_PROVIDER:STRING=package ${_CMAKE_ARGS_OPENSSL_ROOT_DIR} -DCMAKE_INSTALL_PREFIX:PATH=${INSTALL_DIR}/grpc .. && make

cd $dir/thirdparty
if [ ! -d tinyxml2 ]; then
        git clone https://github.com/leethomason/tinyxml2.git
fi
cd tinyxml2
git checkout 7.0.1
mkdir build -p && cd build
cmake -DBUILD_SHARED_LIBS:BOOL=ON .. && make

cd $dir/thirdparty
if [ ! -d cpp-netlib ]; then
        git clone https://github.com/cpp-netlib/cpp-netlib.git
fi
cd cpp-netlib
git checkout cpp-netlib-0.13.0-final
git submodule update --init
mkdir build -p && cd build
cmake -DBUILD_SHARED_LIBS:BOOL=ON .. && make
lib_copy()
{
        local bin=$1
        local dst_lib_dir=$2
        libs=`ldd $bin`
        for lib in $libs;
        do
                if [[ $lib == /*.so* ]]; then
                        continue
                fi
                if [[ $lib == *.so* ]]; then
                        path=`find $dir -name $lib`
                        if [ ! -z "$path" ]; then
                                cp $path $dst_lib_dir
                        fi
                fi
        done
}

cd $dir/thirdparty
mkdir libs -p

path=`find $dir -name *.so*`
if [ ! -z "$path" ]; then
        echo $path
        cp $path libs
fi

export LD_LIBRARY_PATH=$dir/thirdparty/libs:$LD_LIBRARY_PATH
mkdir lib -p
lib_copy /opt/intel/vcaa/vcaa_agent/bin/vcaa_agent lib

