export LD_LIBRARY_PATH=/opt/intel/ddwo/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=/usr/local/lib:$LD_LIBRARY_PATH
export PATH=/opt/intel/ddwo/bin:$PATH
